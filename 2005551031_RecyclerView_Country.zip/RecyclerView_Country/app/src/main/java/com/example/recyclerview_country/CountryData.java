package com.example.recyclerview_country;

import java.util.ArrayList;

public class CountryData {
    private static String [] countryName = {
            "France",
            "Indonesia",
            "Spain",
            "Australia",
            "Canada",
            "South Korea",
            "North Korea",
            "Greece",
            "Turkey",
            "South Africa"
    };

    private static String [] countryDetail = {
            "France, in Western Europe, encompasses medieval cities, alpine villages and Mediterranean beaches. Paris, its capital, is famed for its fashion houses, classical art museums including the Louvre and monuments like the Eiffel Tower.",
            "Indonesia, officially the Republic of Indonesia, is a country in Southeast Asia and Oceania between the Indian and Pacific oceans. It consists of over 17,000 islands, including Sumatra, Sulawesi, Java, and parts of Borneo and New Guinea.",
            "Spain, a country on Europe’s Iberian Peninsula, includes 17 autonomous regions with diverse geography and cultures. Capital city Madrid is home to the Royal Palace and Prado museum, housing works by European masters.",
            "Australia, officially the Commonwealth of Australia, is a sovereign transcontinental country comprising the mainland of the Australian continent, the island of Tasmania, and numerous smaller islands.",
            "Canada is a country in North America. Its ten provinces and three territories extend from the Atlantic to the Pacific and northward into the Arctic Ocean, covering 9.98 million square kilometres, making it the world's second-largest country by total area.",
            "South Korea, an East Asian nation on the southern half of the Korean Peninsula, shares one of the world’s most heavily militarized borders with North Korea. It’s equally known for its green, hilly countryside dotted with cherry trees and centuries-old Buddhist temples, plus its coastal fishing villages, sub-tropical islands and high-tech cities such as Seoul, the capital.",
            "North Korea, officially the Democratic People's Republic of Korea, is a country in East Asia, constituting the northern part of the Korean peninsula. It borders China and Russia to the north, at the Yalu and Tumen rivers, and South Korea to the south at the Korean Demilitarized Zone.",
            "Greece is a country in southeastern Europe with thousands of islands throughout the Aegean and Ionian seas. Influential in ancient times, it's often called the cradle of Western civilization.",
            "Turkey, officially the Republic of Turkey, is a transcontinental country located mainly on Anatolia in Western Asia, with a portion on the Balkans in Southeast Europe.",
            "South Africa is a country on the southernmost tip of the African continent, marked by several distinct ecosystems. Inland safari destination Kruger National Park is populated by big game.",
    };

    private static int[] countryImage = {
            R.drawable.france,
            R.drawable.indonesia,
            R.drawable.spain,
            R.drawable.australia,
            R.drawable.canada,
            R.drawable.sk,
            R.drawable.nk,
            R.drawable.greece,
            R.drawable.turkey,
            R.drawable.za
    };

    static ArrayList<Country> getListData(){
        ArrayList<Country> list = new ArrayList<>();
        for (int position = 0; position <countryName.length; position++){
            Country country = new Country();
            country.setName(countryName[position]);
            country.setDetail(countryDetail[position]);
            country.setPhoto(countryImage[position]);
            list.add(country);
        }
        return list;
    }

}
