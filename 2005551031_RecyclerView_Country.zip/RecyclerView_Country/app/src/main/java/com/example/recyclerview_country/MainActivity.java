package com.example.recyclerview_country;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvCountry;
    private ArrayList<Country> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvCountry = findViewById(R.id.rv_country);
        rvCountry.setHasFixedSize(true);

        list.addAll(CountryData.getListData());
        showList();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.menu_list){
            showList();
        }
        else if (item.getItemId() == R.id.menu_grid){
            showGrid();
        }
        return super.onOptionsItemSelected(item);
    }

    private void showGrid() {
        rvCountry.setLayoutManager(new GridLayoutManager(this, 3));
        GridCountryAdapter gridCountryAdapter = new GridCountryAdapter(list);
        rvCountry.setAdapter(gridCountryAdapter);
    }

    private void showList() {
        rvCountry.setLayoutManager(new LinearLayoutManager(this));
        ListCountryAdapter listCountryAdapter = new ListCountryAdapter(list);
        rvCountry.setAdapter(listCountryAdapter);
    }
}